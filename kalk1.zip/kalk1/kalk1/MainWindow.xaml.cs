﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kalk1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
   

 
        public MainWindow()
        {
            InitializeComponent();
            
            liczone.Text = string.Empty;

        }

        private void przyciskc(object sender, RoutedEventArgs e)
        { if (liczone.Text.Contains("nie"))
                liczone.Text = "";
            var operation = liczone.Text;
            var button = sender as Button;
            char cyfra = button.Name[button.Name.Length - 1];
            int mo = 0, a, w = 0, w0 = 0;
            bool cz = false;
            char d;
            if (cyfra == '0')
            {


                int ce = 0;
                if (operation == "")
                {
                    liczone.Text += cyfra;
                    ce++;
                }

                if (ce < 1)
                {
                    for (int jjj = 0; jjj < operation.Length; jjj++)
                    {
                        d = operation[operation.Length - 1 - jjj];
                        if (d == '0')
                            w0++;

                        if (d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                        {
                            liczone.Text += cyfra;
                            break;
                        }
                        if (d == '-' || d == '+' || d == '/' || d == '*')
                        {
                            if (w0 < 1)
                                liczone.Text += cyfra;

                            break;
                        }
                        if (d == ',')
                        {
                            liczone.Text += cyfra;
                            break;
                        }

                    }
                }


            }
            else
            { if (operation == "")
                    liczone.Text += cyfra;
                else
                {
                    if (operation[operation.Length - 1] == '0')
                    {
                        if (operation.Length > 1)
                        {
                            d = operation[operation.Length - 2];
                            if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9' || d == ',')
                                liczone.Text += cyfra;




                        }

                    }
                    else
                    { liczone.Text += cyfra; }

                } } }
        private bool czyzawiera(string operation)
        { return operation.Contains("+")  || operation.Contains("*") || operation.Contains("/"); }
        private void dodaj(object sender, RoutedEventArgs e)
        {
            if (liczone.Text.Contains("nie"))
                liczone.Text = "";
            var operation = liczone.Text;



            if (operation != "") {
                char d = operation[operation.Length - 1];
                if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                {
                    var ELEMENTS = operation.Split('/');
                    ELEMENTS = operation.Split('*');
                    ELEMENTS = operation.Split('-');
                    ELEMENTS = operation.Split('+');
                    if (czyzawiera(operation))
                    {
                        liczone.Text = Calci(operation);
                    }
                    else
                    {
                        for (int jjj = 1; jjj < operation.Length - 1; jjj++)
                        {
                            if (operation[jjj] == '-')
                                liczone.Text = Calci(operation);
                        }
                    }
                    if (!liczone.Text.Contains("nie"))
                        liczone.Text += "+";
                } }
            }
            
        private void odejmij(object sender, RoutedEventArgs e)
        {
            if (liczone.Text.Contains("nie"))
                liczone.Text = "";
            var operation = liczone.Text;
            if (operation != "")
            {
                char d = operation[operation.Length - 1];
                if (d != '-')
                {

                    var ELEMENTS = operation.Split('/', '-', '+', '*');

                    if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                    {
                        if (czyzawiera(operation))
                        {
                            liczone.Text = Calci(operation);
                        }
                        else
                        {
                            for (int jjj = 1; jjj < operation.Length - 1; jjj++)
                            {
                                if (operation[jjj] == '-')
                                    liczone.Text = Calci(operation);
                            }
                        }
                        if (!liczone.Text.Contains("nie"))
                            liczone.Text += "-";
                    }
                    else
                    {
                        if (!liczone.Text.Contains("nie"))
                            liczone.Text += "-";
                    }
                }

            }
            else
            {
                if (!liczone.Text.Contains("nie"))
                    liczone.Text += "-";
            }
        }
        private void iloczyn(object sender, RoutedEventArgs e)
        {
            if (liczone.Text.Contains("nie"))
                liczone.Text = "";
            var operation = liczone.Text;
            if (operation != "")
            {
                char d = operation[operation.Length - 1];
                if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                {

                    var ELEMENTS = operation.Split('/');
                    ELEMENTS = operation.Split('*');
                    ELEMENTS = operation.Split('-');
                    ELEMENTS = operation.Split('+');
                    if (czyzawiera(operation))
                        liczone.Text = Calci(operation);
                    else
                    {
                        for (int jjj = 1; jjj < operation.Length - 1; jjj++)
                        {
                            if (operation[jjj] == '-')
                                liczone.Text = Calci(operation);
                        }
                    }
                    if (!liczone.Text.Contains("nie"))
                        liczone.Text += "*";
                }
            }
        }
        private void iloraz(object sender, RoutedEventArgs e)
        {
            if (liczone.Text.Contains("nie"))
                liczone.Text = "";
            var operation = liczone.Text;
            
            if (operation != "")
            {
                var ELEMENTS = operation.Split('/');
               
                char d = operation[operation.Length - 1];
                if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                {
                  
                    ELEMENTS = operation.Split('*');
                    ELEMENTS = operation.Split('-');
                    ELEMENTS = operation.Split('+');
                    if (czyzawiera(operation))
                    {




                        liczone.Text = Calci(operation);
                        if (!liczone.Text.Contains("nie"))
                            liczone.Text += "/";

                    }
                    else
                    {
                        for (int jjj = 1; jjj < operation.Length - 1; jjj++)
                        {
                            if (operation[jjj] == '-')
                                liczone.Text = Calci(operation);
                        }
                    }
                    if (!liczone.Text.Contains("nie"))
                        liczone.Text += "/";
                    
                }
            }
        }
        private void czyszczenie1(object sender, RoutedEventArgs e)
        {
            
            liczone.Text = string.Empty;
        }

  
        private void wynik_c(object sender, RoutedEventArgs e)
        {
            if (liczone.Text.Contains("nie"))
                liczone.Text = "";
            var operation = liczone.Text;
         
            if (czyzawiera(operation))
            {
               
               
                char d = operation[operation.Length - 1];
                if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                {

                    if (operation.Contains("/"))
                    {

                        
                            liczone.Text = Calci(operation);
                       
                    }
                    else
                        liczone.Text = Calci(operation);
                }
            }
            else
            {
                for (int jjj = 1; jjj < operation.Length - 1; jjj++)
                {
                    if (operation[jjj] == '-')
                        liczone.Text = Calci(operation);
                }
            }
        }
        private string Calci(string operation)
        {//
            double a = 1,b=1,i,r;
            //if (operation[0] == '-')
            //   a = -1;
            // for (i = 0; i < operation.Length; i++)
            //{
            //  if (operation[i] == '+' || operation[i] == '/' || operation[i] == '*')
            //    if (operation.Length > i + 1)
            //  {
            //    if (operation[i + 1] == '-')
            //  {
            //    b = -1;
            //  c = 1;
            // }
            // }
            //}
            //
            if (operation.Contains("+"))
            {
                var ELEMENTS = operation.Split('+');
                r = a * double.Parse(ELEMENTS[0]) + b * double.Parse(ELEMENTS[1]);
                return r.ToString();

            }
            else
            {
                if (operation.Contains("/"))
                {
                    var ELEMENTS = operation.Split('/');
                    if (double.Parse(ELEMENTS[1])!=0)
                    {
                        r = a * double.Parse(ELEMENTS[0]) / double.Parse(ELEMENTS[1]);
                        return r.ToString();
                    }
                    else
                        return "cholero nie dziel przez 0";


                }
                else
                {
                    if (operation.Contains("*"))
                    {
                        var ELEMENTS = operation.Split('*');
                        r=a * double.Parse(ELEMENTS[0])  * double.Parse(ELEMENTS[1]);
                        return r.ToString();

                    }
                    else
                    {
                        if (operation[0] == '-')
                            a = -1;
                        if (operation.Contains("-"))
                        {
                            var ELEMENTS = operation.Split('-');
                            if (a > 0)
                                r = double.Parse(ELEMENTS[0]) - double.Parse(ELEMENTS[1]);
                            else
                            { double ce = double.Parse(ELEMENTS[1]);
                                ce= -ce;
                               double ic= double.Parse(ELEMENTS[2]);
                                r = ce - ic;
                            }
                            return r.ToString();

                        }
                    }
               
                }
            }
            liczone.Text = string.Empty;
            return "t";
        }
        private void przecinek_c(object sender, RoutedEventArgs e)
        { int ko = 0,lk=0,ol=0;
            ko = 0; lk = 0; ol = 0;
            if (liczone.Text.Contains("nie"))
                liczone.Text = "";
            var operation = liczone.Text;
            if (operation.Contains("+") || operation.Contains("-") || operation.Contains("*") || operation.Contains("/")) { 
                var ELEMENTS = operation.Split('/','*','+','-');
           
                if (ELEMENTS[1].Contains(","))
                {
                 
                    if (operation[0] == '-')
                    {

                        for (int jjj = 1; jjj < operation.Length; jjj++)
                        {
                            if (operation[jjj] == '-' || operation[jjj] == '/' || operation[jjj] == '+' || operation[jjj] == '*')
                                lk = 1;
                            if (operation[jjj] == ',' && lk > 0)
                                ko++;

                        }
                        if (ko < 1 && lk > 0)
                        {

                            char d = operation[operation.Length - 1];
                            if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                                liczone.Text += ",";
                            else
                                liczone.Text += "0,";
                        }

                    }
                    else
                    {
                      
                        lk = 0;ko = 0;
                        for (int jjj = 1; jjj < operation.Length; jjj++)
                        {
                            if (operation[jjj] == '-' || operation[jjj] == '/' || operation[jjj] == '+' || operation[jjj] == '*')
                                lk = 1;
                            if (operation[jjj] == ',' && lk > 0)
                                ko++;
                            
                        }
                        
                        if (ko < 1 && lk > 0)
                        {

                            char d = operation[operation.Length - 1];
                            if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                                liczone.Text += ",";
                            else
                                liczone.Text += "0,";
                        }
                    }
                }
                else
                {
                    lk = 0; ko = 0;
                    int qe= 0;
                ;
                    for (int jjj = 0; jjj < operation.Length ; jjj++)
                    {
                        if (operation[jjj] == '-' || operation[jjj] == '/' || operation[jjj] == '+' || operation[jjj] == '*')
                            lk = 1;
                        if (operation[jjj] == ',' && lk > 0)
                            ko++;
                        if (operation[jjj] == ',' && lk <1)
                            qe++;
                    }
                    if ((ko < 1&&lk>0)||(qe<1&&lk<1))
                    {
                        if (operation != "")
                        {
                            char d = operation[operation.Length - 1];
                            if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                                liczone.Text += ",";
                            else
                                liczone.Text += "0,";
                        }
                        else
                            liczone.Text += "0,";
                    }
                }
  

            }
            else {
                if (operation.Contains(","))
                {  }
                else
                { 
                    if (operation != "")
                    {
                        
                        char d = operation[operation.Length - 1];
                        if (d == '0' || d == '1' || d == '2' || d == '3' || d == '4' || d == '5' || d == '6' || d == '7' || d == '8' || d == '9')
                            liczone.Text += ",";
                        else
                            liczone.Text += "0,";
                    }
                    else
                        liczone.Text += "0,";
                }
            }
        }    

    }

}
